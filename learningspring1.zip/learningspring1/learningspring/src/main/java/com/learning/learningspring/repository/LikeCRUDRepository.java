package com.learning.learningspring.repository;


import org.springframework.data.repository.CrudRepository;

import com.learning.learningspring.entity.LikeId;
import com.learning.learningspring.entity.LikeRecord;
import com.learning.learningspring.entity.Post;

public interface LikeCRUDRepository extends CrudRepository<LikeRecord, LikeId>{
  public Integer countByLikeIdPost(Post post);
}